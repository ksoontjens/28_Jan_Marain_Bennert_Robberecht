import java.lang.*;	//uitzondering, deze doet hij al automatisch dus moet niet 


public class StudentWerknemer extends PartTimeWerknemer{
	
	super.setRSZ((float)0.05);
	
	
}	//einde programma